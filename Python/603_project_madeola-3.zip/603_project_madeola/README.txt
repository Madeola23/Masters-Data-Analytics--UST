I created a BMI calculator.I created inputs that makes the steps easy to follow. My calculator asks you to
first enter your height in inches and insert your weight in pounds. After this it asks you to enter your age and gender
and from there it calculates your BMI. I defined the BMI function and its parameters are weight and height. I used
the formula of Weight/(Height**2) *703 and created an if and elif statements for the age and BMI score
and it returns whether you are healhty or not. The BMI categories are:
  BMI	                BMI Category
 Less than 15	        Very severely underweight
 Between 15 and 16	    Severely underweight
 Between 16 and 18.5	Underweight
 Between 18.5 and 25	Healthy weight
 Between 25 and 30	    Overweight
 Between 30 and 35	    Moderately obese
 Between 35 and 40	    Severely obese
 Over 40	            Very severely or morbidly obese
 In the main function you can see where I call the BMI function. I rounded the score by two and it gives you your score
 and where you are in the BMI category based on your outputs that you put in. See example

'''
Example:
Enter height in inches: 75
Enter weight in pounds: 178
Enter your age in years: 22
Enter your gender: Male
Your BMI is:  22.25 You are:  Healthy weight
'''