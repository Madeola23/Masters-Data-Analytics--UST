filename = input("File to save: ")

with open(filename + ".txt","w" ) as file:
    file.write(input("Insert text file: "))

dict ={}
with open(filename + ".txt") as f:
    line =f.readline()
    while line:
        line = line.strip()

        if line in dict:
            dict[line] +=1
        else:
            dict[line] = 1
        line =f.readline()
print(dict)


