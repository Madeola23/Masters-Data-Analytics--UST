Height = float(input("Enter height in inches: "))
Weight = float(input("Enter weight in pounds: "))
Age = int(input("Enter your age in years: "))
Gender = input("Enter your gender: ")


# BMI	                BMI Category
# Less than 15	        Very severely underweight
# Between 15 and 16	    Severely underweight
# Between 16 and 18.5	Underweight
# Between 18.5 and 25	Healthy weight
# Between 25 and 30	    Overweight
# Between 30 and 35	    Moderately obese
# Between 35 and 40	    Severely obese
# Over 40	             Very severely or morbidly obese


def BMI(Height,Weight):
    bmi_i = Weight/(Height**2) *703
    if Age>=18:
        if bmi_i <15:
            return "Very Severely Underweight",bmi_i
        elif bmi_i >=15 and bmi_i <16:
            return "Severely Underweight",bmi_i
        elif bmi_i >=16 and bmi_i <18.5:
            return "Underweight",bmi_i
        elif bmi_i >=18.5 and bmi_i <25:
            return "Healthy weight",bmi_i
        elif bmi_i >= 25 and bmi_i < 30:
            return "Overweight",bmi_i
        elif bmi_i >= 30 and bmi_i < 35:
            return "Moderately Obese",bmi_i
        elif bmi_i >= 35 and bmi_i < 40:
            return "Severely Obese",bmi_i
        elif bmi_i >= 40:
            return "Very severely or morbidly obese",bmi_i


def main():
    quote,bmi_i =BMI(Height,Weight)
    print("Your BMI is: ",round(bmi_i,2),"You are: ",quote,)

main()


