/*
****************** 
**  Exhibit B SQL 
******************
*/

--Exhibit B, Part B
SELECT ContractorNumber AS "Contractor Number", ContractorName AS "Name", Contractor_Loc_City, Contractor_Loc_State, Contractor_Loc_ZipCode, Contractor_Loc_County AS "County", EEOCCertificate AS "EEOC Compiance Certificate", ExpireDate  AS "Expires On"
FROM CONTRACTOR;

--Exhibit B, Part C
SELECT ProjectNumber AS "Project Number", Project_Loc_Street, Project_Loc_City, Project_Loc_State, Project_Loc_Zipcode,  ProjectDescription AS "Project Description"
FROM PROJECT;


--Exhibit B, Part D
--Total will be calculated by the Front End Application

SELECT s.skillcode || '-' || s.skilldescription AS "Skill Classification"
, SUM (  CASE WHEN e.gender = 'Male' AND e.eeocode != '5' then t.totalhours else 0 end ) As "Minority Male"
, SUM (  CASE WHEN e.gender = 'Female' AND e.eeocode!= '5' then t.totalhours else 0 end  ) As "Minority Female"
, SUM (  CASE WHEN e.gender = 'Male' AND e.eeocode = '5' then t.totalhours else 0 end ) As "Non-Minority Male"
, SUM (  CASE WHEN e.gender = 'Female' AND e.eeocode = '5' then t.totalhours else 0 end  ) As "Non-Minority Female"
, SUM(t.totalhours)  As "Job Hours"
, ROUND(SUM (  CASE WHEN e.gender = 'Female' AND e.eeocode!= '5' then t.totalhours else 0 end  ) / SUM(t.totalhours) * 100,1)  As "% of Hours Worked by Minority Female"
, ROUND(SUM ( CASE WHEN e.eeocode != '5' then t.totalhours Else 0 end) / SUM(t.totalhours)  * 100,1) As "% of Hours Worked by Minority"
FROM SKILL s
JOIN TIMESHEET t ON s.SkillCode = t.SkillCode
JOIN EMPLOYEE e ON t.EmployeeID = e.EmployeeID
GROUP BY s.skillcode || '-' || s.skilldescription;



/*
******************
**  Exhibit C SQL 
******************
*/


--Exhibit C, Part C
--Detailed Pay Scale Breakdown for Regular Hours (Overtime =1.5 X the Basic Rate)

SELECT SkillCode AS Code, SkillDescription AS "Job Classification", BasicHourlyRate AS "Basic Hourly Rate", 
FRINGEBENEFITS AS "Fringe Benefits Payments", TOTALCOMPENSATION AS "Total Compensation"
FROM SKILL;


/*
******************
**  Exhibit D SQL 
******************
*/


-- Exhibit D Part D- Regular Hours
SELECT DISTINCT EMPLOYEE.EmployeeID, SKILL.SkillCode, SKILL.BASICHOURLYRATE, SKILL.FringeBenefits, SKILL.BASICHOURLYRATE+SKILL.FringeBenefits AS Total,    
TIMESHEET.RegularHours, (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours AS Gross
FROM EMPLOYEE JOIN TIMESHEET ON TIMESHEET.EmployeeID = EMPLOYEE.EmployeeID JOIN SKILL ON SKILL.SkillCode = TIMESHEET.SkillCode
WHERE SKILL.SkillCode ='MAS' OR SKILL.SkillCode ='LAB';


--Exhibit D Part E- Overtime Hours
SELECT DISTINCT EMPLOYEE.EmployeeID, SKILL.SkillCode, SKILL.BASICHOURLYRATE, SKILL.FringeBenefits,SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits AS Total, 
TIMESHEET.OverTimeHours, (SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours AS Gross
FROM EMPLOYEE JOIN TIMESHEET ON TIMESHEET.EmployeeID = EMPLOYEE.EmployeeID JOIN SKILL ON SKILL.SkillCode = TIMESHEET.SkillCode
WHERE SKILL.SkillCode = 'EQP';

-- Exhibit D Part F-Total Hours Worked Per Skill Classification
SELECT DISTINCT SKILL.SkillCode, TIMESHEET.RegularHours, TIMESHEET.OverTimeHours, TIMESHEET.RegularHours+TIMESHEET.OverTimeHours AS Total 
FROM TIMESHEET JOIN SKILL ON SKILL.SkillCode = TIMESHEET.SkillCode;

/*
******************
**  Exhibit E SQL 
******************
*/

--Exhibit E
-- example with Social Security # 566-80-5355 

SELECT SocialSecurity AS "Social Security #", 
  LastName AS "Last Name", 
  FirstName AS "First Name", 
  MI AS "M.I.", 
  Address AS "Street", 
  City AS "City", 
  State AS "State", 
  ZipCode AS "Zip Code", 
  Telephonenumber AS "Telephone Number", 
  DOB AS "Date of Birth", 
  Gender AS "Gender", 
  MaritalStatus AS "Marital Status", 
  EEOCode AS "EEO Code"
FROM EMPLOYEE
WHERE SocialSecurity = '566-80-5355';


/*
******************
**  Exhibit F SQL 
******************
*/

--Exhibit F
--Display Employee Basic Information based Employee 1
SELECT DISTINCT FirstName, MI, LastName, SocialSecurity, HireDate, PayPeriod, EXTRACT (YEAR FROM PayPeriod) AS YEAR, MaritalStatus, EEOCode, EMPLOYEE.CheckNumber
FROM    TIMESHEET  JOIN EMPLOYEE ON TIMESHEET. EmployeeID = EMPLOYEE.EmployeeID
WHERE EMPLOYEE.EmployeeID='1';
  
--Exhibit F Display Regular Pay Section            
SELECT DISTINCT TIMESHEET.TimeSheetNumber, EMPLOYEE.EmployeeID,  PROJECT.ProjectNumber, PROJECT.ProjectDescription, SKILL. SkillDescription,
SKILL.BASICHOURLYRATE, SKILL.FringeBenefits, SKILL.BASICHOURLYRATE+SKILL.FringeBenefits AS Total, TIMESHEET.RegularHours, (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours AS Gross_Reg
FROM TIMESHEET  JOIN SKILL ON TIMESHEET.SkillCode = SKILL.SkillCode
JOIN PROJECT ON TIMESHEET. ProjectNumber = PROJECT.ProjectNumber
JOIN EMPLOYEE_PROJECT ON PROJECT. ProjectNumber = EMPLOYEE_PROJECT. ProjectNumber
JOIN EMPLOYEE ON EMPLOYEE_PROJECT. EmployeeID = EMPLOYEE.EmployeeID
WHERE  EMPLOYEE.EmployeeID='1' AND TIMESHEET.RegularHours !=0
ORDER BY TIMESHEET.TimeSheetNumber;
  
--Exhibit F Display Overtime Pay Section     
SELECT DISTINCT TIMESHEET.TimeSheetNumber, EMPLOYEE.EmployeeID,  PROJECT.ProjectNumber, PROJECT.ProjectDescription, SKILL. SkillDescription,SKILL.BASICHOURLYRATE, 
SKILL.FringeBenefits, SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits AS Total, TIMESHEET.OverTimeHours, (SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours AS Gross_OT
FROM TIMESHEET  
JOIN SKILL ON TIMESHEET.SkillCode = SKILL.SkillCode
JOIN PROJECT ON TIMESHEET. ProjectNumber = PROJECT.ProjectNumber
JOIN EMPLOYEE_PROJECT ON PROJECT. ProjectNumber = EMPLOYEE_PROJECT. ProjectNumber
JOIN EMPLOYEE ON EMPLOYEE_PROJECT. EmployeeID = EMPLOYEE.EmployeeID
WHERE  EMPLOYEE.EmployeeID='1' AND TIMESHEET.OverTimeHours NOT IN (0)
ORDER BY PROJECT.ProjectDescription;

--Display Employee Payment Totals Information

SELECT SUM(TIMESHEET.RegularHours) AS TotalRegularPayHours, SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) AS TotalRegularPay,  
SUM (TIMESHEET.OverTimeHours) AS TotalOvertimePayHours, SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours) AS TotalOvertimePay
FROM TIMESHEET  
JOIN SKILL ON TIMESHEET.SkillCode = SKILL.SkillCode
JOIN PROJECT ON TIMESHEET. ProjectNumber = PROJECT.ProjectNumber
JOIN EMPLOYEE_PROJECT ON PROJECT. ProjectNumber = EMPLOYEE_PROJECT. ProjectNumber
JOIN EMPLOYEE ON EMPLOYEE_PROJECT. EmployeeID = EMPLOYEE.EmployeeID
GROUP BY  EMPLOYEE.EmployeeID;

--Weekly Deductions - The deduction rates for each type of tax were assumptions. 
SELECT ROUND( (SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 156.20/798.50,2) AS FederalTax
,ROUND((SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 23.43/798.50,2) AS StateTax
,ROUND ((SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 49.51/798.50,2) AS SocialSecurity
,ROUND((SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 0/798.50,2) AS Other
,ROUND((SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 156.20/798.50
+(SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 23.43/798.50 
+(SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 49.51/798.50
+(SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 0/798.50,2) AS TotalDeductions                               
FROM TIMESHEET
JOIN SKILL ON TIMESHEET.SkillCode = SKILL.SkillCode
JOIN PROJECT ON TIMESHEET. ProjectNumber = PROJECT.ProjectNumber
JOIN EMPLOYEE_PROJECT ON PROJECT. ProjectNumber = EMPLOYEE_PROJECT. ProjectNumber
JOIN EMPLOYEE ON EMPLOYEE_PROJECT. EmployeeID = EMPLOYEE.EmployeeID
GROUP BY  EMPLOYEE.EmployeeID;


-- Display THE Summary section of Exhibit F
SELECT ROUND( SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours),2) AS GrossPaythisWeek
,ROUND((SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 156.20/798.50
+ROUND((SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 23.43/798.50
+(SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 49.51/798.50
+(SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 0/798.50,2),2) AS LessDeductions
,ROUND((SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours) )
-((SUM( (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 156.20/798.50 
+(SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 23.43/798.50 
+(SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 49.51/798.50 
+(SUM(  (SKILL.BASICHOURLYRATE+SKILL.FringeBenefits)*TIMESHEET.RegularHours) + SUM ((SKILL.BASICHOURLYRATE*1.5+SKILL.FringeBenefits)*TIMESHEET.OverTimeHours)) * 0/798.50),2) AS NetPaythisWeek            
FROM TIMESHEET 
JOIN SKILL ON TIMESHEET.SkillCode = SKILL.SkillCode
JOIN PROJECT ON TIMESHEET. ProjectNumber = PROJECT.ProjectNumber
JOIN EMPLOYEE_PROJECT ON PROJECT. ProjectNumber = EMPLOYEE_PROJECT. ProjectNumber
JOIN EMPLOYEE ON EMPLOYEE_PROJECT. EmployeeID = EMPLOYEE.EmployeeID
GROUP BY  EMPLOYEE.EmployeeID;
