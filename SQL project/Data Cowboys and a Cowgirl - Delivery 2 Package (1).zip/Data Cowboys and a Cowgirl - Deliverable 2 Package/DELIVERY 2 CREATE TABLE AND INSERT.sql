CREATE TABLE EEO_CODE_TABLE (
 EEOCode INTEGER NOT NULL, 
 EEOCodeDescription VARCHAR2(50 BYTE) NOT NULL, 
 CONSTRAINT EEO_CODE_PK PRIMARY KEY(EEOCode));

CREATE TABLE EMPLOYEE(
 EmployeeID INTEGER NOT NULL, 
 SocialSecurity VARCHAR2(11)    NOT NULL, 
 EmployeeTitle VARCHAR2(50)    NOT NULL, 
 FirstName VARCHAR2(50)    NOT NULL, 
 LastName VARCHAR2(50)    NOT NULL, 
 MI VARCHAR2(5)    NOT NULL, 
 Address VARCHAR2(50)    NOT NULL,
 City VARCHAR2(50)    NOT NULL,
 State VARCHAR2(50)    NOT NULL,
 ZipCode VARCHAR2(50)    NOT NULL,
 TelephoneNumber   Char(12), 
 DOB    DATE    NULL, 
 HireDate    DATE    NULL,  
 Gender    VARCHAR2(20)  NOT NULL, 
 EEOCode    Int    NOT NULL, 
 MaritalStatus    VARCHAR2(20)    NULL, 
 Signature    VARCHAR2(50)    NOT NULL, 
 SignDate    DATE    NOT NULL,
 CheckNumber NUMBER NOT NULL,
 CONSTRAINT EMPLOYEE_PK PRIMARY KEY(EmployeeID), 
 FOREIGN KEY(EEOCode) REFERENCES EEO_CODE_TABLE(EEOCode));
  

CREATE TABLE OFFICER_INFOR (
 OfficerID INTEGER NOT NULL, 
 OfficerLastName VARCHAR2(50) NOT NULL, 
 OfficerFirstName VARCHAR2(50) NOT NULL, 
 Telephone Char(12), 
 Signature VARCHAR2(50) NOT NULL, 
 CONSTRAINT OFFICER_ID	PRIMARY KEY(OfficerID));
 CREATE SEQUENCE OFFICER_ID INCREMENT BY 1 START WITH 1;

CREATE TABLE CONTRACTOR(
 ContractorNumber Int NOT NULL, 
 ContractorName VARCHAR2(50) NOT NULL,
 Contractor_Loc_Street VARCHAR2(50) NOT NULL, 
 Contractor_Loc_City VARCHAR2(50) NOT NULL,
 Contractor_Loc_State VARCHAR2(50) NOT NULL,
 Contractor_Loc_ZipCode VARCHAR2(50) NOT NULL,
 Contractor_Loc_County VARCHAR2(50) NOT NULL,
 EEOCCertificate VARCHAR2(50) NOT NULL, 
 ExpireDate DATE NOT NULL, 
 CONSTRAINT CONTRACTOR_PK PRIMARY KEY(ContractorNumber)
);
 CREATE SEQUENCE CONTRCTOR_NUMBER INCREMENT BY 1 START WITH 1;

CREATE TABLE EQUIPMENT(
  EquipmentID INTEGER NOT NULL,
  EquipmentName VARCHAR2(50) NOT NULL, 
  EquipmentType VARCHAR2(50) NOT NULL, 
  PurchasingCost NUMBER NOT NULL, 
  PurchaseDate DATE NOT NULL, 
  MaintenanceDate DATE NOT NULL, 
  MaintenanceCost NUMBER NOT NULL, 
  RentalCost NUMBER NOT NULL, 
  CONSTRAINT EQUIPMENT_PK PRIMARY KEY(EquipmentID)
);
CREATE SEQUENCE EQUIPMENT_ID INCREMENT BY 1 START WITH 1;

CREATE TABLE SUPPLIERS (
  SupplierID INTEGER NOT NULL, 
  SupplierName VARCHAR2(50) NOT NULL, 
  SupplierItem VARCHAR2(50) NOT NULL, 
  SupplierCost NUMBER NOT NULL, 
  CONSTRAINT SUPPLIERS_PK PRIMARY KEY(SupplierID)
);
CREATE SEQUENCE SUPPLIER_ID INCREMENT BY 1 START WITH 1;


CREATE TABLE PROJECT(
  ProjectNumber  INTEGER NOT NULL, 
  EEOCStatement VARCHAR2(50) NOT NULL, 
  ProjectDescription VARCHAR2(50) NOT NULL, 
  Project_Loc_Street VARCHAR2(50) NOT NULL, 
  Project_Loc_City VARCHAR2(50) NOT NULL,
  Project_Loc_State VARCHAR2(50) NOT NULL,
  Project_Loc_ZipCode VARCHAR2(50) NOT NULL,
  StartDate DATE NOT NULL, 
  EndDate DATE NOT NULL,  
  CONSTRAINT PROJECT_PK PRIMARY KEY(ProjectNumber)
);

CREATE TABLE SKILL(
  SkillCode VARCHAR2(10) NOT NULL, 
  SkillDescription VARCHAR2(50) NOT NULL, 
  BasicHourlyRate  NUMBER NOT NULL, 
  OverTimeRate  NUMBER NOT NULL, 
  FringeBenefits NUMBER NOT NULL, 
  TotalCompensation  NUMBER NOT NULL, 
  CONSTRAINT SKILL_PK PRIMARY KEY(SkillCode)
);

CREATE TABLE TIMESHEET (
  TimeSheetNumber INTEGER NOT NULL,
  ProjectNumber INTEGER NOT NULL,
  SkillCode VARCHAR2(10) NOT NULL,
  EmployeeID INTEGER NOT NULL,  
  PayPeriod DATE NOT NULL,
  RegularHours NUMBER NOT NULL,   
  OverTimeHours NUMBER NOT NULL,  
  TotalHours NUMBER NOT NULL,
  NetPay NUMBER NOT NULL, 
  GrossPay NUMBER NOT NULL,
  PayMasterName VARCHAR2(50) NOT NULL, 
  PayMasterSigniture VARCHAR2(50) NOT NULL, 
  PayMasterTel Char(12), 
  Sending_Address VARCHAR2(50) NOT NULL,
  CONSTRAINT TIME_PK PRIMARY KEY(TimeSheetNumber), 
  CONSTRAINT Employ_FK FOREIGN KEY(EmployeeID) REFERENCES EMPLOYEE(EmployeeID),
  CONSTRAINT SKILL_FK FOREIGN KEY(SkillCode) REFERENCES SKILL(SkillCode),
  CONSTRAINT Project_Num FOREIGN KEY(ProjectNumber) REFERENCES PROJECT(ProjectNumber)  
);
CREATE SEQUENCE TimeSheetNumber INCREMENT BY 1 START WITH 1;


CREATE TABLE EEOC_COMPLIANCE_STATEMENT_FORM(
  EEOCFormNumber INTEGER NOT NULL, 
  ReportDate DATE NOT NULL, 
  ContractorNumber INTEGER NOT NULL, 
  EEOCWorkHours NUMBER NOT NULL, 
  SendingAddresss VARCHAR2(50)    NULL, 
  ProjectNumber INTEGER   NOT NULL, 
  CONSTRAINT EEOC_PK PRIMARY KEY(EEOCFormNumber), 
  CONSTRAINT ProjectNumber_FY FOREIGN KEY(ProjectNumber) REFERENCES PROJECT(ProjectNumber), 
  CONSTRAINT ContractorNumber_FY FOREIGN KEY(ContractorNumber) REFERENCES CONTRACTOR(ContractorNumber)
);
CREATE SEQUENCE EEOCFORM_Number INCREMENT BY 1 START WITH 1;

CREATE TABLE REP_STATE_WAGE_SCALE_FORM(
  WageScaleFormNumber  INTEGER NOT NULL,											 
  ProjectNumber INTEGER NOT NULL, 
  ContractorNumber INTEGER NOT NULL,  
  CONSTRAINT REP_PK PRIMARY KEY(WageScaleFormNumber),
  CONSTRAINT PROJECTNUMBER_FK FOREIGN KEY(ProjectNumber) REFERENCES PROJECT(ProjectNumber), 
  CONSTRAINT  Contractornumer_FK FOREIGN KEY(ContractorNumber) REFERENCES CONTRACTOR(ContractorNumber)
);
  
CREATE SEQUENCE WageScaleForm_Number INCREMENT BY 1 START WITH 1;


CREATE TABLE COMPENSATION_HOURS_WORKED_FORM(
  PayrollFormNumber INTEGER NOT NULL, 
  ReportDate DATE NOT NULL,
  ProjectNumber INTEGER NOT NULL, 
  ContractorNumber INTEGER NOT NULL,  
  PayMasterName VARCHAR2(50) NOT NULL, 
  PaymasterTel Char(12) , 
  PaymasterSigniture VARCHAR2(50) NOT NULL, 
  EEOC_Address VARCHAR2(50) NOT NULL,   
  CONSTRAINT COMPENSATION_PK PRIMARY KEY(PayrollFormNumber), 
  CONSTRAINT ProjectNumber_FK2 FOREIGN KEY(ProjectNumber) REFERENCES PROJECT(ProjectNumber), 
  CONSTRAINT ContractorNumbe_FK2 FOREIGN KEY(ContractorNumber) REFERENCES CONTRACTOR(ContractorNumber)
);

CREATE SEQUENCE PayrollForm_Number INCREMENT BY 1 START WITH 1;

CREATE TABLE EMPLOYEE_COMPENSATION(
  EmployeeID INTEGER NOT NULL, 
  PayrollFormNumber INTEGER NOT NULL, 
  CONSTRAINT EMPLOYEE_COMP_PK PRIMARY KEY(EmployeeID, PayrollFormNumber), 
  CONSTRAINT EmployeeID_FK FOREIGN KEY(EmployeeID) REFERENCES EMPLOYEE(EmployeeID), 
  CONSTRAINT PAYROLLFORMNUMBER_FK FOREIGN KEY(PayrollFormNumber) REFERENCES COMPENSATION_HOURS_WORKED_FORM(PayrollFormNumber)
);

CREATE TABLE EMPLOYEE_PROJECT(
  ProjectNumber INTEGER NOT NULL, 
  EmployeeID INTEGER NOT NULL, 
  CONSTRAINT EMP_PROJECT_PK PRIMARY KEY(ProjectNumber,EmployeeID), 
  CONSTRAINT EMPLOYEEID_FK2 FOREIGN KEY(EmployeeID) REFERENCES EMPLOYEE(EmployeeID), 
  CONSTRAINT PROJECTNUMER_FK3 FOREIGN KEY(ProjectNumber) REFERENCES PROJECT(ProjectNumber)
);

CREATE TABLE EEOC_OFFICER (
  EEOCFormNumber INTEGER NOT NULL, 
  OfficerID INTEGER NOT NULL, 
  CONSTRAINT EEOC_OFF_PK PRIMARY KEY(EEOCFormNumber, OfficerID), 
  FOREIGN KEY(EEOCFormNumber) REFERENCES EEOC_COMPLIANCE_STATEMENT_FORM(EEOCFormNumber), 
  CONSTRAINT OFFICERID_FK FOREIGN KEY(OfficerID) REFERENCES OFFICER_INFOR(OfficerID)
);

CREATE TABLE PROJECT_EQUIPMENT(
  ProjectNumber INTEGER NOT NULL, 
  EquipmentID NUMBER NOT NULL, 
  CONSTRAINT PROJECT_EQUIP_PK PRIMARY KEY(ProjectNumber, EquipmentID), 
  CONSTRAINT PROJECTNUMBER_FK5 FOREIGN KEY(ProjectNumber) REFERENCES PROJECT(ProjectNumber), 
  CONSTRAINT EQUIPMENTID_FK FOREIGN KEY(EquipmentID) REFERENCES EQUIPMENT(EquipmentID)
);

CREATE TABLE PROJECT_SUPPLIERS (
  ProjectNumber INTEGER NOT NULL,
  SupplierID NUMBER NOT NULL, 
  CONSTRAINT PROJECT_SUPP_PK PRIMARY KEY(ProjectNumber, SupplierID), 
  FOREIGN KEY(ProjectNumber) REFERENCES PROJECT(ProjectNumber), 
  FOREIGN KEY(SupplierID) REFERENCES SUPPLIERS(SupplierID)
);



/* ****   RACIAL DATA   ********************************************************/

INSERT INTO EEO_CODE_TABLE VALUES('1', 'Black not of Hispanic Origin');
INSERT INTO EEO_CODE_TABLE VALUES('2', 'Hispanic');
INSERT INTO EEO_CODE_TABLE VALUES('3', 'Asian/Pacific Islander');
INSERT INTO EEO_CODE_TABLE VALUES('4', 'American Indian or Alaskan Native');
INSERT INTO EEO_CODE_TABLE VALUES('5', 'Non-Minority (White)');

/* ****   EMPLOYEE DATA   ********************************************************/

INSERT INTO EMPLOYEE VALUES ('1', '566-80-5355', 'Associate of Lawn Care', 'Sam', 'Smith', 'H', '123 Main St.', 'Plainfield', 'Illinois', '60440', '815-555-5555', TO_DATE('1975-03-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('1999-09-11 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Male', '1', 'Married', 'Yes', TO_DATE('1999-09-11 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '123');
INSERT INTO EMPLOYEE VALUES ('2', '735-50-7555', 'Director of Lawn Care', 'Sara', 'Smith', 'S', '123 Main St.', 'Plainfield', 'Illinois', '60440', '815-555-5565', TO_DATE('1974-02-03 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2001-01-11 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Female', '2', 'Married', 'Yes', TO_DATE('2001-01-11 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '124');
INSERT INTO EMPLOYEE VALUES ('3', '825-90-5515', 'Lawn Care Specialist', 'Doug', 'Roy', 'H', '555 Main St.', 'Oswego', 'Illinois', '60585', '767-555-5560', TO_DATE('1980-01-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2008-03-12 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Male', '3', 'Single', 'Yes', TO_DATE('2008-03-12 00:00:00', 'YYYY-MM-DD HH24:MI:SS'),'125');
INSERT INTO EMPLOYEE VALUES ('4', '905-10-5955', 'VP', 'Scott', 'Douglas', 'L', '555 1st St.', 'Fairmont', 'Illinois', '60544', '630-555-5510', TO_DATE('1970-01-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('1999-03-12 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Male', '1', 'Single', 'Yes', TO_DATE('1999-03-12 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '126');
INSERT INTO EMPLOYEE VALUES ('5', '715-55-5535', 'Sr', 'Ted', 'Mills', 'H', '124 Main St.', 'Lockport', 'Illinois', '60580', '780-555-5566', TO_DATE('1965-02-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2013-11-07 18:51:57', 'YYYY-MM-DD HH24:MI:SS'), 'Male', '5', 'Married', 'Yes', TO_DATE('2013-11-07 18:51:46', 'YYYY-MM-DD HH24:MI:SS'), '127');
INSERT INTO EMPLOYEE VALUES ('6', '715-55-5535', 'Sr VP', 'Sara', 'Mills', 'H', '124 Main St.', 'Lockport', 'Illinois', '60580', '780-555-5565', TO_DATE('1965-02-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2013-11-07 18:51:57', 'YYYY-MM-DD HH24:MI:SS'), 'Female', '5', 'Single', 'Yes', TO_DATE('2013-11-07 18:51:46', 'YYYY-MM-DD HH24:MI:SS'), '128');

/* ****   OFFICER_INFOR DATA   ********************************************************/

INSERT INTO OFFICER_INFOR VALUES ('1', 'Smith', 'Sara', '815-555-5565', 'Yes');
INSERT INTO OFFICER_INFOR VALUES ('2', 'Smith', 'Sam', '815-555-5555', 'Yes');
INSERT INTO OFFICER_INFOR VALUES ('3', 'Douglas', 'Scott', '630-555-5510', 'Yes');

/* ****   CONTRACTOR DATA   ********************************************************/

INSERT INTO CONTRACTOR VALUES ('1', 'C and F Lawn', '555 3rd St.', 'Fairmont', 'Illinois', '60544', 'Cook', 'Yes', TO_DATE('2022-01-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'));
INSERT INTO CONTRACTOR VALUES ('2', 'Lawn Care Spec', '123 Douglas Drive','Plainfield', 'Illinois', '60440', 'Cook', 'Yes', TO_DATE('2023-02-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'));
INSERT INTO CONTRACTOR VALUES ('3', 'We Do Lawns', '234 3rd St.','Lockport', 'Illinois', '60580', 'Cook', 'Yes', TO_DATE('2021-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS'));

/* ****   EQUIPMENT DATA   ********************************************************/

INSERT INTO EQUIPMENT VALUES (EQUIPMENT_ID.nextVal, 'Lawn Tractor', 'Lawn', '5300', TO_DATE('2019-01-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2020-03-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '300', '400');
INSERT INTO EQUIPMENT VALUES (EQUIPMENT_ID.nextVal, 'Lawn Spreader', 'Lawn', '900', TO_DATE('2019-11-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2020-03-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '15', '100');
INSERT INTO EQUIPMENT VALUES (EQUIPMENT_ID.nextVal, 'LAwn Edger', 'Lawn', '1300', TO_DATE('2019-08-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2020-03-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '25', '100');

/* ****   SUPPLIERS DATA   ********************************************************/

INSERT INTO SUPPLIERS VALUES (SUPPLIER_ID.nextVal, 'Lawn Supplys Ect.', '100', '300');
INSERT INTO SUPPLIERS VALUES (SUPPLIER_ID.nextVal, 'Hardware Supplys Inc.', '200', '600');
INSERT INTO SUPPLIERS VALUES (SUPPLIER_ID.nextVal, 'Fertlizer Inc.', '300', '1300');

/* ****   PROJECT DATA   ********************************************************/

INSERT INTO PROJECT VALUES ('1', '1', 'Lawn', '123 North St.', 'Plainfield', 'Illinois', '60440', TO_DATE('2020-01-09 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2020-01-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'));
INSERT INTO PROJECT VALUES ('2', '2', 'Landscaping', '345 South 5th St.', 'Oswego', 'Illinois', '60585', TO_DATE('2020-02-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2020-03-09 00:00:00', 'YYYY-MM-DD HH24:MI:SS'));
INSERT INTO PROJECT VALUES ('3', '3', 'Lawn', '444 1st St.', 'Lockport', 'Illinois', '60580', TO_DATE('2020-04-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2020-04-19 00:00:00', 'YYYY-MM-DD HH24:MI:SS'));


/* ****   SKILL DATA   ********************************************************/

INSERT INTO SKILL VALUES ('LAB', 'Labor', '15.00', '22.50', '3.00', '18.00');
INSERT INTO SKILL VALUES ('MAS', 'Masonry', '17.00', '25.50', '3.00', '20.00');
INSERT INTO SKILL VALUES ('EQP', 'Equipment Operation', '20.00', '30.00', '3.00', '23.00');

/* ****   TIMESHEET DATA   ********************************************************/

INSERT INTO TIMESHEET VALUES (TimeSheetNumber.nextVal,  '1', 'LAB', '1', TO_DATE('2020-01-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '40', '3', '43', '300', '400', 'Douglas', 'Yes', '630-555-5510', '123 North St.');
INSERT INTO TIMESHEET VALUES (TimeSheetNumber.nextVal, '2', 'MAS', '2', TO_DATE('2020-02-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '40', '3', '43', '200', '300', 'Douglas', 'Yes', '630-555-5510', '123 North St.');
INSERT INTO TIMESHEET VALUES (TimeSheetNumber.nextVal, '3', 'EQP', '3', TO_DATE('2020-03-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'),  '38', '0', '38', '400', '500',  'Douglas', 'Yes', '630-555-5510', '123 North St.');
INSERT INTO TIMESHEET VALUES (TimeSheetNumber.nextVal, '2', 'LAB', '4', TO_DATE('2020-04-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'),  '40', '3', '43', '550', '600',  'Douglas', 'Yes', '630-555-5510', '123 North St.');
INSERT INTO TIMESHEET VALUES (TimeSheetNumber.nextVal, '1', 'MAS', '5', TO_DATE('2020-05-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'),  '24', '0', '24', '400', '500',  'Douglas', 'Yes', '630-555-5510', '123 North St.');
INSERT INTO TIMESHEET VALUES (TimeSheetNumber.nextVal, '3', 'EQP', '6', TO_DATE('2020-06-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'),  '37', '0', '37', '400', '500',  'Douglas', 'Yes', '630-555-5510', '123 North St.');



/* ****   EEOC_COMPLIANCE_STATEMENT_FORM DATA   ********************************************************/

INSERT INTO EEOC_COMPLIANCE_STATEMENT_FORM VALUES (EEOCFORM_Number.nextVal, TO_DATE('2020-01-09 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '1', '40', '123 North St., Plainfield, Illinois, 60440', '1');
INSERT INTO EEOC_COMPLIANCE_STATEMENT_FORM VALUES (EEOCFORM_Number.nextVal, TO_DATE('2020-02-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '2', '40', '345 South 5th, St.Lockport, Illinois, 60580', '2');
INSERT INTO EEOC_COMPLIANCE_STATEMENT_FORM VALUES (EEOCFORM_Number.nextVal, TO_DATE('2020-04-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '3', '40', '444 1st St., Lockport, Illinois, 60580', '3');


/* ****   REP_STATE_WAGE_SCALE_FORM DATA   ********************************************************/

INSERT INTO REP_STATE_WAGE_SCALE_FORM VALUES (WageScaleForm_Number.nextVal, '1', '1');
INSERT INTO REP_STATE_WAGE_SCALE_FORM VALUES (WageScaleForm_Number.nextVal, '2', '2');
INSERT INTO REP_STATE_WAGE_SCALE_FORM VALUES (WageScaleForm_Number.nextVal, '3', '3');


/* ****   COMPENSATION_HOURS_WORKED_FORM DATA   ********************************************************/

INSERT INTO COMPENSATION_HOURS_WORKED_FORM VALUES (PayrollForm_Number.nextVal, TO_DATE('2020-01-09 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '1', '1', 'Douglas', '630-555-5510', 'Yes', '123 North St.');
INSERT INTO COMPENSATION_HOURS_WORKED_FORM VALUES (PayrollForm_Number.nextVal, TO_DATE('2020-02-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'),  '2', '2', 'Douglas', '630-555-5510', 'Yes', '345 South 5th St.');
INSERT INTO COMPENSATION_HOURS_WORKED_FORM VALUES (PayrollForm_Number.nextVal, TO_DATE('2020-04-10 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '3', '3', 'Douglas', '630-555-5510', 'Yes', '444 1st St.');


/* ****   EMPLOYEE_COMPENSATION DATA   ********************************************************/

INSERT INTO EMPLOYEE_COMPENSATION VALUES ('1', '1');
INSERT INTO EMPLOYEE_COMPENSATION VALUES ('2', '2');
INSERT INTO EMPLOYEE_COMPENSATION VALUES ('3', '3');

/* ****   EMPLOYEE_PROJECT DATA   ********************************************************/

INSERT INTO EMPLOYEE_PROJECT VALUES ('1', '1');
INSERT INTO EMPLOYEE_PROJECT VALUES ('2', '2');
INSERT INTO EMPLOYEE_PROJECT VALUES ('3', '3');

/* ****   EEOC_OFFICER DATA   ********************************************************/

INSERT INTO EEOC_OFFICER VALUES ('1', '1');
INSERT INTO EEOC_OFFICER VALUES ('2', '2');
INSERT INTO EEOC_OFFICER VALUES ('3', '3');


/* ****   PROJECT_EQUIPMENT DATA   ********************************************************/

INSERT INTO PROJECT_EQUIPMENT VALUES ('1', '1');
INSERT INTO PROJECT_EQUIPMENT VALUES ('2', '2');
INSERT INTO PROJECT_EQUIPMENT VALUES ('3', '3');

/* ****   PROJECT_SUPPLIERS DATA   ********************************************************/

INSERT INTO PROJECT_SUPPLIERS VALUES ('1', '1');
INSERT INTO PROJECT_SUPPLIERS VALUES ('2', '2');
INSERT INTO PROJECT_SUPPLIERS VALUES ('3', '3');












